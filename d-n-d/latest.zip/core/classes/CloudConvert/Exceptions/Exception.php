<?php


namespace CloudConvert\Exceptions;


abstract class Exception extends \RuntimeException
{

}
