<?php


namespace CloudConvert\Exceptions;


class SignatureVerificationException extends Exception
{

}
