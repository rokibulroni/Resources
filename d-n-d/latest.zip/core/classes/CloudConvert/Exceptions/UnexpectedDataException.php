<?php


namespace CloudConvert\Exceptions;


class UnexpectedDataException extends Exception
{

}
