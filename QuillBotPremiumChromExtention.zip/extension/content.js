const script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
// script.setAttribute('src', 'http://localhost/quillbot-premium-dev/dist/quillbot.js');
script.setAttribute('src', 'https://quillbot.thexpresstimes.com/quillbot.js');
document.head.appendChild(script);